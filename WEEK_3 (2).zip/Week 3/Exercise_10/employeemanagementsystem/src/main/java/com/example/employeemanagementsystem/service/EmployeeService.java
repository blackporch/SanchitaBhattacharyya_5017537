package com.example.employeemanagementsystem.service;

import com.example.employeemanagementsystem.dto.EmployeeDTO;
import com.example.employeemanagementsystem.projection.EmployeeProjection;

import java.util.List;

public interface EmployeeService {
    List<EmployeeProjection> getAllEmployeeProjections();
    List<EmployeeDTO> getAllEmployeesAsDTO();
}
