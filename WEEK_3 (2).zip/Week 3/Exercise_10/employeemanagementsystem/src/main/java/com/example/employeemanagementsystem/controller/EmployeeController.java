package com.example.employeemanagementsystem.controller;

import com.example.employeemanagementsystem.dto.EmployeeDTO;
import com.example.employeemanagementsystem.entity.Employee;
import com.example.employeemanagementsystem.projection.EmployeeProjection;
import com.example.employeemanagementsystem.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping("/projections")
    public List<EmployeeProjection> getAllEmployeesProjected() {
        return employeeRepository.findAllProjectedBy();
    }

    @GetMapping("/projections/{id}")
    public ResponseEntity<EmployeeProjection> getEmployeeProjectedById(@PathVariable Long id) {
        EmployeeProjection projection = employeeRepository.findProjectedById(id);
        if (projection == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().body(projection);
    }

    @GetMapping("/dto/{id}")
    public ResponseEntity<EmployeeDTO> getEmployeeDTOById(@PathVariable Long id) {
        EmployeeDTO dto = employeeRepository.findDTOById(id);
        if (dto == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().body(dto);
    }
}
