package com.example.employeemanagementsystem.repository;

import com.example.employeemanagementsystem.dto.EmployeeDTO;
import com.example.employeemanagementsystem.entity.Employee;
import com.example.employeemanagementsystem.projection.EmployeeProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<EmployeeProjection> findAllProjectedBy();

    @Query("SELECT e.id as id, e.name as name, e.email as email, d.name as departmentName " +
           "FROM Employee e JOIN e.department d WHERE e.id = :id")
    EmployeeProjection findProjectedById(@Param("id") Long id);

    @Query("SELECT new com.example.employeemanagementsystem.dto.EmployeeDTO(e.id, e.name, e.email, d.name) " +
           "FROM Employee e JOIN e.department d WHERE e.id = :id")
    EmployeeDTO findDTOById(@Param("id") Long id);
}
