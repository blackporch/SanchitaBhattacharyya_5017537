package com.example.employeemanagementsystem.repository;

import com.example.employeemanagementsystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findByDepartmentName(String departmentName);
    Employee findByEmail(String email);
    List<Employee> findByName(String name);
    
    @Query(name = "Employee.findByDepartmentName")
    List<Employee> findEmployeesByDepartmentName(@Param("departmentName") String departmentName);

    @Query(name = "Employee.findByEmail")
    Employee findEmployeeByEmail(@Param("email") String email);

    @Query(name = "Employee.findByName")
    List<Employee> findEmployeesByName(@Param("name") String name);
}

