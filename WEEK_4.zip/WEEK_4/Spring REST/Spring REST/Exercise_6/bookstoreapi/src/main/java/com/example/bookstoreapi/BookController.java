package com.example.bookstoreapi;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import com.example.bookstoreapi.exception.BookNotFoundException;

import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpHeaders;


import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    private List<Book> books = new ArrayList<>();

    // Constructor to add some initial books
    public BookController() {
        books.add(new Book(1L, "1984", "George Orwell", 9.99, "978-0451524935"));
        books.add(new Book(2L, "To Kill a Mockingbird", "Harper Lee", 7.99, "978-0060935467"));
    }
   
    // GET all books
    @GetMapping
    @ResponseStatus(HttpStatus.OK)  // 200 OK
    public List<Book> getAllBooks() {
        return books;
    }

    // GET a book by ID
    @GetMapping("/{id}")
    public Book getBookById(@PathVariable Long id) {
        return books.stream()
                .filter(book -> book.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new BookNotFoundException("Book with ID " + id + " not found"));
    }


    // GET on title and author using query parameters
   /* @GetMapping("/search")
    public List<Book> searchBooks(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String author) {
    
        return books.stream()
                .filter(book -> (title == null || book.getTitle().equalsIgnoreCase(title)) &&
                                (author == null || book.getAuthor().equalsIgnoreCase(author)))
                .toList();
    } */
    // POST a new book
    @PostMapping
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        // Adding the new book to the list (or saving it to the database)
        books.add(book);
    
        // Creating HttpHeaders object to hold custom headers
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "CustomHeaderValue");

        // Returning ResponseEntity with the book object, headers, and status code
        return new ResponseEntity<>(book, headers, HttpStatus.CREATED);
    }

    // PUT to update a book by ID
    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)  // 200 OK
    public Book updateBook(@PathVariable Long id, @RequestBody Book updatedBook) {
        Book book = books.stream()
                .filter(b -> b.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Book Not Found"));

        book.setTitle(updatedBook.getTitle());
        book.setAuthor(updatedBook.getAuthor());
        book.setPrice(updatedBook.getPrice());
        book.setIsbn(updatedBook.getIsbn());
        return book;
    }

    // DELETE a book by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        // Find the book by ID
        Book book = books.stream()
                .filter(b -> b.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Book Not Found"));

        // Remove the book from the list
        books.remove(book);

        // Create custom headers
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "DeletedBook");

        // Return ResponseEntity with no content (Void), custom headers, and status 204
        return new ResponseEntity<>(headers, HttpStatus.NO_CONTENT);
    }

}
