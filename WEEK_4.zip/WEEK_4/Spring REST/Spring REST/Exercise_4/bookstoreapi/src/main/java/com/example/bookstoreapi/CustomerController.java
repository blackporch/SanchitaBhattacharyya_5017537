package com.example.bookstoreapi;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private List<Customer> customers = new ArrayList<>();

    // POST endpoint to create a new customer
    @PostMapping
    public Customer createCustomer(@RequestBody Customer customer) {
        customers.add(customer);
        return customer;
    }

    // Constructor to add some initial customers (optional)
    public CustomerController() {
        customers.add(new Customer(1L, "Alice Johnson", "alice@example.com", "password123"));
        customers.add(new Customer(2L, "Bob Smith", "bob@example.com", "password456"));
    }

    // GET endpoint to retrieve all customers (for testing purposes)
    @GetMapping
    public List<Customer> getAllCustomers() {
        return customers;
    }

    // POST endpoint to process form data for customer registration
    @PostMapping("/register")
    public Customer registerCustomer(
            @RequestParam String name,
            @RequestParam String email,
            @RequestParam String password) {
        
        Customer customer = new Customer();
        customer.setId((long) (customers.size() + 1));
        customer.setName(name);
        customer.setEmail(email);
        customer.setPassword(password);

        customers.add(customer);
        return customer;
    }
}
