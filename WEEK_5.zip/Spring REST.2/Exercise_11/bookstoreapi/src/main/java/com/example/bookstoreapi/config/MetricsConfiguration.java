package com.example.bookstoreapi.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MetricsConfiguration<MeterRegistry> {

    public static final String Tag = null;

    @SuppressWarnings("rawtypes")
    @Bean
    public CustomMetrics customMetrics(MeterRegistry meterRegistry) {
        return new CustomMetrics(meterRegistry);
    }

    public static class CustomMetrics<MeterRegistry> {

        private final MeterRegistry meterRegistry;

        public CustomMetrics(MeterRegistry meterRegistry) {
            this.meterRegistry = meterRegistry;
            registerMetrics();
        }

        private void registerMetrics() {
            // Example of custom counter
            //((Object) meterRegistry).counter("books.added", Tag("type", "custom"), 0);
        }

        private Object Tag(String string, String string2) {
            // TODO Auto-generated method stub
            throw new UnsupportedOperationException("Unimplemented method 'Tag'");
        }
    }
}

