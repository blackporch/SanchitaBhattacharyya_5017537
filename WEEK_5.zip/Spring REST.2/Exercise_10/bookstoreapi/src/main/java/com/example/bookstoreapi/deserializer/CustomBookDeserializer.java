package com.example.bookstoreapi.deserializer;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.example.bookstoreapi.dto.BookDTO;

import java.io.IOException;

public class CustomBookDeserializer extends JsonDeserializer<BookDTO> {
    @Override
    public BookDTO deserialize(JsonParser p, DeserializationContext ctxt)
            throws IOException, JsonProcessingException {
        // Custom deserialization logic here
        // Example: manually parse JSON to create BookDTO
        return new BookDTO(); // Replace with actual deserialized object
    }
}
