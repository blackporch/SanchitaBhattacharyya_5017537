package com.example.bookstoreapi.controller;

import com.example.bookstoreapi.assembler.BookResourceAssembler;
import com.example.bookstoreapi.model.Book;
import com.example.bookstoreapi.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<Book>> getBookById(@PathVariable Long id, @RequestHeader(HttpHeaders.ACCEPT) String acceptHeader) {
        Book book = bookService.getBook(id);
        EntityModel<Book> bookModel = new BookResourceAssembler().toModel(book);
        
        // Respond based on the Accept header
        if (acceptHeader.contains(MediaType.APPLICATION_XML_VALUE)) {
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_XML)
                    .body(bookModel);
        } else {
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(bookModel);
        }
    }

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<Book>>> getAllBooks(@RequestHeader(HttpHeaders.ACCEPT) String acceptHeader) {
        List<EntityModel<Book>> books = bookService.getAllBooks().stream()
                
                .collect(Collectors.toList());
        CollectionModel<EntityModel<Book>> bookCollection = CollectionModel.of(books);
        
        // Respond based on the Accept header
        if (acceptHeader.contains(MediaType.APPLICATION_XML_VALUE)) {
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_XML)
                    .body(bookCollection);
        } else {
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(bookCollection);
        }
    }

    public Class<?> getBookById(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getBookById'");
    }

    public Class<?> getAllBooks() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getAllBooks'");
    }

    // Add other endpoints as needed
}
