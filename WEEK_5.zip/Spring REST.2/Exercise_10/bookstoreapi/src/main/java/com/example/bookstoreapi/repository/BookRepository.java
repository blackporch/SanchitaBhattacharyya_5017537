package com.example.bookstoreapi.repository;

import com.example.bookstoreapi.model.Book;
import org.springframework.stereotype.Repository;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

    void deleteById(Long id);
    // You can define custom query methods here if needed

    boolean existsById(Long id);

    Book save(Book book);

    Object findById(Long id);
}
