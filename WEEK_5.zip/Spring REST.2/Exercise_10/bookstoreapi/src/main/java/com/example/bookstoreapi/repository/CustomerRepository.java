package com.example.bookstoreapi.repository;

import com.example.bookstoreapi.model.Customer;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

    Customer save(Customer customer);
    // You can define custom query methods here if needed

    boolean existsById(Long id);

    Object findById(Long id);

    List<Customer> findAll();

    void deleteById(Long id);
}
