package com.example.bookstoreapi.service;

import com.example.bookstoreapi.model.Book;
import com.example.bookstoreapi.repository.BookRepository;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    private final BookRepository bookRepository;

    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public Book createBook(Book book) {
        return bookRepository.save(book);
    }

    /*public Book getBook(Long id) {
        return bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id " + id));
    }
    */

    public Book updateBook(Long id, Book book) throws Exception {
        if (!bookRepository.existsById(id)) {
            throw new Exception("Book not found");
        }
        book.setId(id);
        return bookRepository.save(book);
    }

    public void deleteBook(Long id) throws Exception {
        if (!bookRepository.existsById(id)) {
            throw new Exception("Book not found");
        }
        bookRepository.deleteById(id);
    }

    public Book getBook(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getBook'");
    }
}
