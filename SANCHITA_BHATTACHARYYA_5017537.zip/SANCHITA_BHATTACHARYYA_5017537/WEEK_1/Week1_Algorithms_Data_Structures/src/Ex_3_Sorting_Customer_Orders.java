import java.util.*;

class Order {
    private String id;
    private String clientName;
    private double amount;

    public Order(String id, String clientName, double amount) {
        this.id = id;
        this.clientName = clientName;
        this.amount = amount;
    }

    public String getId() {
        return id;
    }

    public String getClientName() {
        return clientName;
    }

    public double getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return "Order [id=" + id + ", clientName=" + clientName + ", amount=" + amount + "]";
    }
}

class BubbleSort {
    public static void bubbleSortByAmount(Order[] orders) {
        int n = orders.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (orders[j].getAmount() > orders[j + 1].getAmount()) {
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                }
            }
        }
    }
}

class QuickSort {
    public static void quickSortByAmount(Order[] orders, int low, int high) {
        if (low < high) {
            int pi = partition(orders, low, high);
            quickSortByAmount(orders, low, pi - 1);
            quickSortByAmount(orders, pi + 1, high);
        }
    }

    private static int partition(Order[] orders, int low, int high) {
        double pivot = orders[high].getAmount();
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (orders[j].getAmount() <= pivot) {
                i++;
                Order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
        Order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;

        return i + 1;
    }
}

public class SortingCustomerOrders {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("O001", "Alice", 500.00),
            new Order("O002", "Bob", 150.75),
            new Order("O003", "Charlie", 300.40),
            new Order("O004", "Diana", 220.90)
        };

        System.out.println("Original Orders:");
        for (Order order : orders) {
            System.out.println(order);
        }

        BubbleSort.bubbleSortByAmount(orders);
        System.out.println("\nOrders Sorted by Bubble Sort:");
        for (Order order : orders) {
            System.out.println(order);
        }

        orders = new Order[] {
            new Order("O001", "Alice", 500.00),
            new Order("O002", "Bob", 150.75),
            new Order("O003", "Charlie", 300.40),
            new Order("O004", "Diana", 220.90)
        };

        QuickSort.quickSortByAmount(orders, 0, orders.length - 1);
        System.out.println("\nOrders Sorted by Quick Sort:");
        for (Order order : orders) {
            System.out.println(order);
        }
    }
}
