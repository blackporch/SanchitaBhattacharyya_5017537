import java.util.*;

class Product {
    private String id;
    private String name;
    private String type;

    public Product(String id, String name, String type) {
        this.id = id;
        this.name = name;
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    @Override
    public String toString() {
        return "Product [id=" + id + ", name=" + name + ", type=" + type + "]";
    }
}

class LinearSearch {
    public static Product linearSearchById(Product[] products, String id) {
        for (Product product : products) {
            if (product.getId().equals(id)) {
                return product;
            }
        }
        return null;
    }

    public static Product linearSearchByName(Product[] products, String name) {
        for (Product product : products) {
            if (product.getName().equals(name)) {
                return product;
            }
        }
        return null;
    }

    public static Product linearSearchByType(Product[] products, String type) {
        for (Product product : products) {
            if (product.getType().equals(type)) {
                return product;
            }
        }
        return null;
    }
}

class BinarySearch {
    public static Product binarySearchById(Product[] products, String id) {
        Arrays.sort(products, Comparator.comparing(Product::getId));
        int left = 0, right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getId().compareTo(id);
            if (comparison == 0) {
                return products[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static Product binarySearchByName(Product[] products, String name) {
        Arrays.sort(products, Comparator.comparing(Product::getName));
        int left = 0, right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getName().compareTo(name);
            if (comparison == 0) {
                return products[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static Product binarySearchByType(Product[] products, String type) {
        Arrays.sort(products, Comparator.comparing(Product::getType));
        int left = 0, right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getType().compareTo(type);
            if (comparison == 0) {
                return products[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }
}

public class EcommercePlatformSearch {
    public static void main(String[] args) {
        Product[] products = {
            new Product("P001", "Smartphone", "Electronics"),
            new Product("P002", "Laptop", "Electronics"),
            new Product("P004", "Washing Machine", "Home Appliances"),
            new Product("P003", "Microwave Oven", "Home Appliances"),
            new Product("P005", "Air Conditioner", "Electronics")
        };

        System.out.println("Linear Search by ID: " + LinearSearch.linearSearchById(products, "P003"));
        System.out.println("Linear Search by Name: " + LinearSearch.linearSearchByName(products, "Washing Machine"));
        System.out.println("Linear Search by Type: " + LinearSearch.linearSearchByType(products, "Electronics"));

        System.out.println("Binary Search by ID: " + BinarySearch.binarySearchById(products, "P003"));
        System.out.println("Binary Search by Name: " + BinarySearch.binarySearchByName(products, "Washing Machine"));
        System.out.println("Binary Search by Type: " + BinarySearch.binarySearchByType(products, "Electronics"));
    }
}
