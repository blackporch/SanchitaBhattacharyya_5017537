public class Ex_7_Financial_Forecasting {

    public static double calculateProjectedValue(double principal, double rate, int time) {
        if (time == 0) {
            return principal;
        }
        return calculateProjectedValue(principal * (1 + rate), rate, time - 1);
    }

    public static void main(String[] args) {
        double principalAmount = 2000.0;
        double annualGrowthRate = 0.04;
        int duration = 15;
        double projectedValue = calculateProjectedValue(principalAmount, annualGrowthRate, duration);
        System.out.println("Projected Value: $" + projectedValue);
    }
}
